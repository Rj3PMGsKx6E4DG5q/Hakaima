//
//  NADNativeLabel.h
//  NendAd
//
//  Copyright (c) 2015年 F@N Communications, Inc. All rights reserved.
//  This class will be deleted in the future.

#import <UIKit/UIKit.h>

__attribute__((deprecated("This class will be deleted in the future.")))
@interface NADNativeLabel : UILabel

@end
