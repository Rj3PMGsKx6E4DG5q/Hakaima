//
//  NADUnityGlobal.h
//  Unity-iPhone
//

NSString* NADUnityCreateNSString(const char* string);
char* NADUnityMakeStringCopy(NSString* string);
void NADUnityCacheObject(NSObject *object);
void NADUnityRemoveObject(NSObject *object);
