﻿namespace NendUnityPlugin.AD.Native
{
	using System;

	/// <summary>
	/// The Text for native ad.
	/// </summary>
	/// \deprecated Use `UnityEngine.UI.Text` instead.
	[Obsolete ("Use `UnityEngine.UI.Text` instead.", false)]
	public class NendAdNativeText : UnityEngine.UI.Text
	{

	}
}
