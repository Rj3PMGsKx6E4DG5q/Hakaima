﻿namespace NendUnityPlugin.AD.Native
{
	using System;

	/// <summary>
	/// The RawImage for native ad.
	/// </summary>
	/// \deprecated Use `UnityEngine.UI.RawImage` instead.
	[Obsolete ("Use `UnityEngine.UI.RawImage` instead.", false)]
	public class NendAdNativeImage : UnityEngine.UI.RawImage
	{

	}
}